var gl;
var sceneProgram;
var depthProgram;
var depthFramebuffer;
var vertexBuffer;
var indexBuffer;
var vertexIndices;
var depthTexture;
var shadowMapLocation;
var MVCamera;
var ProjectionLocation;
var CameraStartingPosition;
var CameraView;
var CameraProjection;
var ReverseLightVector;
var LightLocation;
var LightProjection;
var LightView;
var MVLight;
var MVLightDepth;
var TextureCorrectionMap;
var MVTexture;
var MVLightCasted;
var vertexData = [];
var vertexData32f = [];
var Objects = [];
var ModelBuffer = [];
var verticeRanges = [];
var textureBuffer;
var texturesBuffer = [];

function MatrixMul(a,b) {
  let c = [
  0,0,0,0,
  0,0,0,0,
  0,0,0,0,
  0,0,0,0]
  for(let i=0;i<4;i++) {
      for(let j=0;j<4;j++) {
          c[i*4+j] = 0.0;
          for(let k=0;k<4;k++){
              c[i*4+j]+= a[i*4+k] * b[k*4+j];
          }
      }
  }
  return c;
}

function BasicCube(Width, Height, Depth, x, y, z) {
  return new Float32Array([
    //     X           Y          Z     R   G   B    U   V       Normal
    -Width + x,-Height + y,-Depth + z, 0.0,0.8,0.0, 0.0,0.0, -1.0,0.0,0.0,
    -Width + x, Height + y, Depth + z, 0.0,0.8,0.0, 0.0,0.0, -1.0,0.0,0.0,
    -Width + x, Height + y,-Depth + z, 0.0,0.8,0.0, 0.0,0.0, -1.0,0.0,0.0,
    -Width + x,-Height + y, Depth + z, 0.0,0.8,0.0, 0.0,0.0, -1.0,0.0,0.0,
    -Width + x, Height + y, Depth + z, 0.0,0.8,0.0, 0.0,0.0, -1.0,0.0,0.0,
    -Width + x,-Height + y,-Depth + z, 0.0,0.8,0.0, 0.0,0.0, -1.0,0.0,0.0,

     Width + x,-Height + y,-Depth + z, 0.0,0.8,0.0, 0.0,0.0,  1.0,0.0,0.0,
     Width + x, Height + y,-Depth + z, 0.0,0.8,0.0, 0.0,0.0,  1.0,0.0,0.0,
     Width + x, Height + y, Depth + z, 0.0,0.8,0.0, 0.0,0.0,  1.0,0.0,0.0,
     Width + x, Height + y, Depth + z, 0.0,0.8,0.0, 0.0,0.0,  1.0,0.0,0.0,
     Width + x,-Height + y, Depth + z, 0.0,0.8,0.0, 0.0,0.0,  1.0,0.0,0.0,
     Width + x,-Height + y,-Depth + z, 0.0,0.8,0.0, 0.0,0.0,  1.0,0.0,0.0,

    -Width + x,-Height + y,-Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,-1.0,0.0,
     Width + x,-Height + y,-Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,-1.0,0.0,
     Width + x,-Height + y, Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,-1.0,0.0,
     Width + x,-Height + y, Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,-1.0,0.0,
    -Width + x,-Height + y, Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,-1.0,0.0,
    -Width + x,-Height + y,-Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,-1.0,0.0,

    -Width + x, Height + y,-Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,1.0,0.0,
     Width + x, Height + y, Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,1.0,0.0,
     Width + x, Height + y,-Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,1.0,0.0,
    -Width + x, Height + y, Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,1.0,0.0,
     Width + x, Height + y, Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,1.0,0.0,
    -Width + x, Height + y,-Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,1.0,0.0,

     Width + x,-Height + y,-Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,0.0,-1.0,
    -Width + x,-Height + y,-Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,0.0,-1.0,
     Width + x, Height + y,-Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,0.0,-1.0,
    -Width + x, Height + y,-Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,0.0,-1.0,
     Width + x, Height + y,-Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,0.0,-1.0,
    -Width + x,-Height + y,-Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,0.0,-1.0,

    -Width + x,-Height + y, Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,0.0,1.0,
     Width + x,-Height + y, Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,0.0,1.0,
     Width + x, Height + y, Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,0.0,1.0,
     Width + x, Height + y, Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,0.0,1.0,
    -Width + x, Height + y, Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,0.0,1.0,
    -Width + x,-Height + y, Depth + z, 0.0,0.8,0.0, 0.0,0.0,  0.0,0.0,1.0,
  ]);
}

function CompileProgram(gl, ShaderSource, FragmentSource) {
  // Create basic program
  const Program = gl.createProgram();

  // Compile shader
  const Shader = gl.createShader(gl.VERTEX_SHADER);
  gl.shaderSource(Shader, ShaderSource);
  gl.compileShader(Shader);
  // Hook up shader
  gl.attachShader(Program, Shader);

  // Compile fragment
  const Fragment = gl.createShader(gl.FRAGMENT_SHADER);
  gl.shaderSource(Fragment, FragmentSource);
  gl.compileShader(Fragment);
  // Hook up fragment
  gl.attachShader(Program, Fragment);

  // Bake and send program to GPU
  gl.linkProgram(Program);

  // Debug if program 💩 itself
  if (!gl.getProgramParameter(Program, gl.LINK_STATUS)) {
    console.log(gl.getShaderInfoLog(Shader));
    console.log(gl.getShaderInfoLog(Fragment));
  }

  return Program;
}

function VectorAbs(Vector) { return Math.hypot(Vector.x, Vector.y, Vector.z); }

function VectorNormalize(Vector) {
  var Abs = VectorAbs(Vector);
  if (Abs == 0) { return new DOMPoint(0, 0, 0); }
  return new DOMPoint(Vector.x / Abs, Vector.y / Abs, Vector.z / Abs);
}

function VectorSub(VectorA, VectorB) { return new DOMPoint(VectorA.x - VectorB.x, VectorA.y - VectorB.y, VectorA.z - VectorB.z); }

function VectorDotAbs(VectorA, VectorB) { return VectorA.x * VectorB.x + VectorA.y * VectorB.y + VectorA.z * VectorB.z; }

function VectorCross(VectorA, VectorB) {
  let x = VectorA.y * VectorB.z - VectorA.z * VectorB.y;
  let y = VectorA.z * VectorB.x - VectorA.x * VectorB.z;
  let z = VectorA.x * VectorB.y - VectorA.y * VectorB.x;
  return new DOMPoint(x, y, z);
}

function CreatePerspective(FOV, Aspect, ZNear, ZFar) {
  var FOVrads = FOV * Math.PI / 180;
  var Focal = Math.tan((Math.PI - FOVrads) / 2);
  var ZRangeInverse = 1.0 / (ZNear - ZFar);
  return new DOMMatrix([
    Focal / Aspect, 0, 0, 0,
    0, Focal, 0, 0,
    0, 0, (ZNear + ZFar) * ZRangeInverse, -1,
    0, 0, ZNear * ZFar * ZRangeInverse * 2, 0
  ]);
}

// https://en.wikipedia.org/wiki/Orthographic_projection
function CreateOrthogonalPerspective(Left, Right, Top, Bottom, Near, Far) {
  return new DOMMatrix([
    2 / (Right - Left), 0, 0, 0,
    0, 2 / (Top - Bottom), 0, 0,
    0, 0, -2 / (Far - Near), 0,
    -(Right + Left) / (Right - Left), -(Top + Bottom) / (Top - Bottom), -(Far + Near) / (Far - Near), 1,
  ]);
}

function LookAt(From, To) {
  // Z is pointing straight away from camera
  var zAxis = VectorNormalize(VectorSub(To, From));
  // Z crossed with direct up vector = X axis pointing to the right
  var xAxis = VectorNormalize(VectorCross(zAxis, new DOMPoint(0, 1, 0)));
  // Y axis from crossing the other 2
  var yAxis = VectorCross(xAxis, zAxis);

  const Inverse = new DOMPoint(zAxis.x * -1, zAxis.y * -1, zAxis.z * -1);

  return new DOMMatrix([
    xAxis.x, yAxis.x, Inverse.x, 0,
    xAxis.y, yAxis.y, Inverse.y, 0,
    xAxis.z, yAxis.z, Inverse.z, 0,
    -VectorDotAbs(xAxis, From), -VectorDotAbs(yAxis, From), -VectorDotAbs(Inverse, From), 1,
  ]);
}

// OBJ to raw vertice data - bc gl.drawElements is acting dumb
async function OBJ2Raw(URL) {
  // Offset arrays by 1 so actual data starts with index 1 - makes assembling faces easier
  var Positions = [[]];
  var Textures = [[]];
  var Normals = [[]];
  var Faces = [];
  var Buffer = [];

  // unfiltered fetching but don't have time for fancier code
  let Response = await fetch(URL);
  if (!Response.ok) { throw new Error(`HTTP error! status: ${Response.status}`); }

  let OBJFile = await Response.text();
  let Lines = OBJFile.split('\n');
  for(let Line of Lines) {
    let Words = Line.split(' ');
    switch(Words[0]) {
      case 'v':
        let Point = [Words[1], Words[2], Words[3]];
        Positions.push(Point);
        break;
      case 'vt':
        let UVPoint = [Words[1], Words[2]];
        Textures.push(UVPoint);
        break;
      case 'vn':
        let Normal = [Words[1], Words[2], Words[3]];
        Normals.push(Normal);
        break;
      case 'f':
        let Point1 = Words[1].split('/');
        let Point2 = Words[2].split('/');
        let Point3 = Words[3].split('/');
        let Face = [];

        // Point 1
        Face.push(Positions[Point1[0]][0]);
        Face.push(Positions[Point1[0]][1]);
        Face.push(Positions[Point1[0]][2]);
        Face.push(1.0);
        Face.push(1.0);
        Face.push(1.0);
        Face.push(Textures[Point1[1]][0]);
        Face.push(Textures[Point1[1]][1]);
        Face.push(Normals[Point1[2]][0]);
        Face.push(Normals[Point1[2]][1]);
        Face.push(Normals[Point1[2]][2]);

        // Point 2
        Face.push(Positions[Point2[0]][0]);
        Face.push(Positions[Point2[0]][1]);
        Face.push(Positions[Point2[0]][2]);
        Face.push(1.0);
        Face.push(1.0);
        Face.push(1.0);
        Face.push(Textures[Point2[1]][0]);
        Face.push(Textures[Point2[1]][1]);
        Face.push(Normals[Point2[2]][0]);
        Face.push(Normals[Point2[2]][1]);
        Face.push(Normals[Point2[2]][2]);

        // Point 3
        Face.push(Positions[Point3[0]][0]);
        Face.push(Positions[Point3[0]][1]);
        Face.push(Positions[Point3[0]][2]);
        Face.push(1.0);
        Face.push(1.0);
        Face.push(1.0);
        Face.push(Textures[Point3[1]][0]);
        Face.push(Textures[Point3[1]][1]);
        Face.push(Normals[Point3[2]][0]);
        Face.push(Normals[Point3[2]][1]);
        Face.push(Normals[Point3[2]][2]);

        Faces.push(...Face);
        break;
      default: break;
    }
  }
  
  console.log("Loaded: " + URL + " with " + Faces.length / 11 + " polygons.");
  Buffer = new Float32Array(Faces);
  return Buffer;
}

function Randomf(Min, Max, CanBeNegative) {
  let Negative = Math.random() < 0.5;
  if(Negative && CanBeNegative) {
    return -(Math.random() * (Max - Min) + Min);
  } else {
    return Math.random() * (Max - Min) + Min;
  }
}

// Settings
const shadowResolution = 4096;
const GlobalVOF = 60;
const GlobalRatio = 16 / 9;
const MovementStep  = 0.05;
const MovementAngle = 0.40;
const FPSLimiter = 1000 / 120; // 120 FPS

var CameraX =  0;
var CameraY =  3;
var CameraZ =  10;

var LightX = -1;
var LightY =  1;
var LightZ = -1;

const depthVertexShader = `#version 300 es
  layout(location=0) in vec4 aVertexPosition;
  uniform mat4 MVLight;
  uniform mat4 MVModel;

  void main(){
    // position = light perspective * point position
    gl_Position = MVLight * MVModel * aVertexPosition;
  }`;

const depthFragmentShader = `#version 300 es
  precision highp float;
  out float Depth;

  void main(){
    // get depth
    Depth = gl_FragCoord.z;
  }`;

const programVertexShader = `#version 300 es
  layout(location=0) in vec4 aVertexPosition; // positions
  layout(location=1) in vec3 aVertexColor;    // RGB color
  layout(location=2) in vec2 aVertexCoords;   // UV texture coords
  layout(location=3) in vec3 aVertexNormal;   // normals
  uniform mat4 MVCamera;
  uniform mat4 MVLight;
  uniform mat4 MVModel;
  out vec4 MVPLight;
  out vec3 vColor;
  out vec2 vCoords;
  out vec3 vNormal;

  void main()
  {
    vCoords = aVertexCoords;
    vColor = aVertexColor;
     
    mat3 NormalMatrix = mat3(transpose(inverse(MVModel)));

    // translate normals so scaled objects don't cast shadows of themselfs
    vNormal = normalize(NormalMatrix * aVertexNormal);

    // Update positions with transform matrix
    MVPLight = MVLight * MVModel * aVertexPosition; 
    gl_Position = MVCamera * MVModel * aVertexPosition;
  }`;


const programFragmentShader = `#version 300 es
  precision highp float;
  uniform vec3 LightDirection;
  uniform highp sampler2DShadow shadowMapTexture;
  uniform sampler2D uSampler;                      // Regular texture sampler
  in vec2 vCoords;                                 // UV coordinates
  in vec3 vColor;                                  // Vertex color
  in vec3 vNormal;                                 // Normal vector
  in vec4 MVPLight;                                // Light-transformed position
  out vec3 fragColor;                              // Output color
  uniform bool OverrideTexture;
  uniform bool OverrideLight;

  // Light level in darkness
  const float AmbientLight = 0.20;

  // Light level in shadow
  const float ShadowLight = 0.30;

  // Floating Point Error Correction
  const float FPEC = 0.002;

  void main()
  {
    // Position with floating point glitching removed
    vec3 vPosition = vec3(MVPLight.x, MVPLight.y, MVPLight.z - FPEC);

    // Compare from texture if fragment is in shadow
    float IsInLight = texture(shadowMapTexture, vPosition);

    // Normalize vectors if they're not already
    vec3 nNormal = normalize(vNormal);

    // Calculate light intensity from light direction and normal
    float LightCosine = dot(LightDirection, nNormal);

    // Decide whether fragment is in light or shadow
    float LightLevel = max(IsInLight, ShadowLight);

    // Determine the final brightness of the fragment
    float Brightness = max(LightLevel * LightCosine, AmbientLight);

    // Get texture color
    vec4 textureColor = texture(uSampler, vCoords);

    // Apply shadow and output the final color
    if(OverrideLight) {Brightness = 1.0;}
    if(OverrideTexture) {
      fragColor = vColor * Brightness;
    } else {
      fragColor = textureColor.rgb * Brightness;
    }
  }`;

async function GLSetup() {
  // Basic WebGL setup
  gl = document.querySelector('canvas').getContext('webgl2');
  gl.enable(gl.DEPTH_TEST);
  gl.enable(gl.CULL_FACE);
  sceneProgram = CompileProgram(gl, programVertexShader, programFragmentShader);
  depthProgram = CompileProgram(gl, depthVertexShader, depthFragmentShader);

  // Setup Light
  gl.useProgram(sceneProgram);
  ReverseLightVector = VectorNormalize(new DOMPoint(LightX, LightY, LightZ)); //normalized so only really gives an angle
  LightLocation = gl.getUniformLocation(sceneProgram, 'LightDirection');
  gl.uniform3fv(LightLocation, new Float32Array([ReverseLightVector.x, ReverseLightVector.y, ReverseLightVector.z]));
  LightProjection = CreateOrthogonalPerspective(-10, 10, 10, -10, -10, 10); // good enough projection size, mess up the program shader to see light perspective
  LightView = LookAt(ReverseLightVector, new DOMPoint(0, 0, 0));
  MVLight = LightProjection.multiply(LightView);
  MVLightDepth = gl.getUniformLocation(depthProgram, 'MVLight');
  gl.useProgram(depthProgram);
  gl.uniformMatrix4fv(MVLightDepth, false, MVLight.toFloat32Array());

  // [-1,1] -> [0,1] (UV)
  TextureCorrectionMap = new DOMMatrix([
    0.5, 0.0, 0.0, 0.0,
    0.0, 0.5, 0.0, 0.0,
    0.0, 0.0, 0.5, 0.0,
    0.5, 0.5, 0.5, 1.0
  ]);
  // Light perspective coordinates -> texture coordinates
  MVTexture = TextureCorrectionMap.multiplySelf(MVLight);
  // Update coordinate mapping in shader program
  MVLightCasted = gl.getUniformLocation(sceneProgram, 'MVLight');
  gl.useProgram(sceneProgram);
  gl.uniformMatrix4fv(MVLightCasted, false, MVTexture.toFloat32Array());

  // Camera setup
  CameraStartingPosition = new DOMPoint(CameraX, CameraY, CameraZ);
  CameraView = LookAt(CameraStartingPosition, new DOMPoint(0, CameraY, 0));
  CameraProjection = CreatePerspective(GlobalVOF, GlobalRatio, 0.001, 100); //FOV [deg], aspect ratio, Z-near, Z-far
  MVCamera = CameraProjection.multiply(CameraView);
  ProjectionLocation = gl.getUniformLocation(sceneProgram, 'MVCamera');
  gl.uniformMatrix4fv(ProjectionLocation, false, MVCamera.toFloat32Array());

  // Setup objects
  //      ID     Model    X     Y     Z    Scale   RotX   RotY   RotZ   Texture
  Objects[ 0] = [  0,    0.0,  0.0,  0.0,   1.0,    0.0,   0.0,   0.0,      1   ];
  Objects[ 1] = [  2,    4.0,  0.0,  4.0,   1.0,    0.0,   0.0,   0.0,      3   ];
  Objects[ 2] = [  2,   -4.0,  0.0, -4.0,   0.8,    0.0,   0.0,   0.0,      3   ];
  
  // MAKE IT RAAAAAAAAIN
  let Last = Objects.length;
  for(let i = Last; i < Last + 30; i++) {
    Objects[i] = [1,Randomf(1.5, 6.0, true),Randomf(1.5, 6.0, false),Randomf(1.5, 6.0, true),Randomf(0.1, 0.3, false),
    Randomf(0, 180, true),Randomf(0, 180, true),Randomf(0, 180, true),2];
  }

  // Setup object matrixes
  for(let i = 0; i < Objects.length; i++) {
    var X  = Objects[i][1];
    var Y  = Objects[i][2];
    var Z  = Objects[i][3];
    var S  = Objects[i][4];
    var Rx = Objects[i][5];
    var Ry = Objects[i][6];
    var Rz = Objects[i][7];

    Objects[i][9] = [
      S,0,0,0,
      0,S,0,0,
      0,0,S,0,
      0,0,0,1
    ];

    let uMVRotX = [
      1,0,0,0,
      0,+Math.cos(Rx*Math.PI/180.0),+Math.sin(Rx*Math.PI/180.0),0,
      0,-Math.sin(Rx*Math.PI/180.0),+Math.cos(Rx*Math.PI/180.0),0,
      0,0,0,1];
    Objects[i][9] = MatrixMul(Objects[i][9], uMVRotX);
    
    let uMVRotY = [
      +Math.cos(Ry*Math.PI/180.0),0,-Math.sin(Ry*Math.PI/180.0),0,
      0,1,0,0,
      +Math.sin(Ry*Math.PI/180.0),0,+Math.cos(Ry*Math.PI/180.0),0,
      0,0,0,1];
    Objects[i][9] = MatrixMul(Objects[i][9], uMVRotY);
      
    let uMVRotZ = [
      +Math.cos(Rz*Math.PI/180.0),+Math.sin(Rz*Math.PI/180.0),0,0,
      -Math.sin(Rz*Math.PI/180.0),+Math.cos(Rz*Math.PI/180.0),0,0,
      0,0,1,0,
      0,0,0,1];
    Objects[i][9] = MatrixMul(Objects[i][9], uMVRotZ);

    let Loc = [
      1,0,0,0,
      0,1,0,0,
      0,0,1,0,
      X,Y,Z,1
    ];
    Objects[i][9] = MatrixMul(Objects[i][9], Loc);
  }

  // Load models
  vertexData.push(...BasicCube(7, 0.1, 7,  0, 0, 0)); // Floor - always present
  verticeRanges[-2] = vertexData.length / 11;
  vertexData.push(...await OBJ2Raw('sphere.obj')); // Light Object - always present
  verticeRanges[-1] = vertexData.length / 11;
  vertexData.push(...await OBJ2Raw('building.obj'));
  verticeRanges[ 0] = vertexData.length / 11;
  vertexData.push(...await OBJ2Raw('donut.obj'));
  verticeRanges[ 1] = vertexData.length / 11;
  vertexData.push(...await OBJ2Raw('umbrella.obj'));
  verticeRanges[ 2] = vertexData.length / 11;
  vertexData32f = new Float32Array(vertexData);

  // 4 in 1 buffer
  vertexBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, vertexData32f, gl.STATIC_DRAW);

  // Position 3 x float (4B)
  gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 44, 0);
  gl.enableVertexAttribArray(0);

  // RGB 3 x float (4B)
  gl.vertexAttribPointer(1, 3, gl.FLOAT, false, 44, 12);
  gl.enableVertexAttribArray(1);

  // UV 2 x float (4B)
  gl.vertexAttribPointer(2, 2, gl.FLOAT, false, 44, 24);
  gl.enableVertexAttribArray(2);

  // Normal 3 x float (4B)
  gl.vertexAttribPointer(3, 3, gl.FLOAT, false, 44, 32);
  gl.enableVertexAttribArray(3);

  // Load textures
  let textureWidth = 500;
  let textureHeight = 500;
  var textureImg = new Image();
  textureImg.onload = function() {
      for(let Tx = 0; Tx < 4; Tx++){
          for(let Ty = 0; Ty < 4; Ty++){
              textureBuffer = gl.createTexture();
              gl.bindTexture(gl.TEXTURE_2D, textureBuffer);

              let canvas = document.createElement('canvas');
              canvas.width = textureWidth;
              canvas.height = textureHeight;
              let tmpCanvas = canvas.getContext('2d');
              tmpCanvas.drawImage(textureImg, Ty * textureWidth, Tx * textureHeight, textureWidth, textureHeight, 0, 0, textureWidth, textureHeight);

              gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, canvas);
              gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
              gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
              gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);

              texturesBuffer.push(textureBuffer);
          }
      }
  }
  textureImg.src="textures.jpg";

  // Setup depth map texture
  depthTexture = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, depthTexture);
  gl.texStorage2D(gl.TEXTURE_2D, 1, gl.DEPTH_COMPONENT32F, shadowResolution, shadowResolution);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_MODE, gl.COMPARE_REF_TO_TEXTURE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

  // Setup light perspective rendered frame buffer
  depthFramebuffer = gl.createFramebuffer();
  gl.bindFramebuffer(gl.FRAMEBUFFER, depthFramebuffer);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, depthTexture, 0);
  shadowMapLocation = gl.getUniformLocation(sceneProgram, 'shadowMapTexture');

  // Start render loop
  Tick();
}

function Tick() {
  MoveCamera();
  MoveLight();

  gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);

  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

  // Renderuj scene z widoku światła
  gl.useProgram(depthProgram);
  gl.bindFramebuffer(gl.FRAMEBUFFER, depthFramebuffer);
  gl.viewport(0, 0, shadowResolution, shadowResolution);

  for (let i = 0; i < Objects.length; i++) {
    var ModelID = Objects[i][0];
    var ModelMat = Objects[i][9];
    gl.uniformMatrix4fv(gl.getUniformLocation(depthProgram, "MVModel"), false, new Float32Array(ModelMat));
    gl.drawArrays(gl.TRIANGLES, verticeRanges[ModelID - 1], verticeRanges[ModelID] - verticeRanges[ModelID - 1]);
  }
  
  var ViewModel = [
    1,0,0,0,
    0,1,0,0,
    0,0,1,0,
    0,0,0,1
  ];
  gl.uniformMatrix4fv(gl.getUniformLocation(depthProgram, "MVModel"), false, new Float32Array(ViewModel));
  gl.drawArrays(gl.TRIANGLES, 0, verticeRanges[-2]);


  // Renderowanie sceny dla kamery używając tekstury cienia
  gl.useProgram(sceneProgram);
  gl.clearColor(10/255, 10/255, 50/255, 1.0);
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);
  gl.clearDepth(1.0);
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, depthTexture);
  gl.uniform1i(shadowMapLocation, 0);

  gl.uniform1i(gl.getUniformLocation(sceneProgram, "OverrideTexture"), 0);
  gl.uniform1i(gl.getUniformLocation(sceneProgram, "OverrideLight"), 0);
  for (let i = 0; i < Objects.length; i++) {
    var ModelID = Objects[i][0];
    var ModelMat = Objects[i][9];

    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, texturesBuffer[Objects[i][8]]);
    gl.uniform1i(gl.getUniformLocation(sceneProgram, "uSampler"), 1);
    gl.uniformMatrix4fv(gl.getUniformLocation(sceneProgram, "MVModel"), false, new Float32Array(ModelMat));
    gl.drawArrays(gl.TRIANGLES, verticeRanges[ModelID - 1], verticeRanges[ModelID] - verticeRanges[ModelID - 1]);
  }

  gl.uniform1i(gl.getUniformLocation(sceneProgram, "OverrideTexture"), 1);
  var ViewModel = [
    1,0,0,0,
    0,1,0,0,
    0,0,1,0,
    0,0,0,1
  ];
  gl.uniformMatrix4fv(gl.getUniformLocation(sceneProgram, "MVModel"), false, new Float32Array(ViewModel));
  gl.drawArrays(gl.TRIANGLES, 0, verticeRanges[-2]);

  gl.uniform1i(gl.getUniformLocation(sceneProgram, "OverrideLight"), 1);
  gl.uniform1i(gl.getUniformLocation(sceneProgram, "OverrideTexture"), 0);
  gl.bindTexture(gl.TEXTURE_2D, texturesBuffer[0]);
  gl.uniform1i(gl.getUniformLocation(sceneProgram, "uSampler"), 1);
  var ViewModel = [
    0.1,0,0,0,
    0,0.1,0,0,
    0,0,0.1,0,
    LightX,LightY,LightZ,0.05
  ];
  gl.uniformMatrix4fv(gl.getUniformLocation(sceneProgram, "MVModel"), false, new Float32Array(ViewModel));
  gl.drawArrays(gl.TRIANGLES, verticeRanges[-2], verticeRanges[-1] - verticeRanges[-2]);

  setTimeout(Tick, FPSLimiter);
}

let KeyStates = [];
function HandleKeyEventUp(event) {KeyStates[event.keyCode] = false;}
function HandleKeyEventDown(event) {KeyStates[event.keyCode] = true; console.log(event.keyCode);}
function MoveCamera() {
  if(KeyStates[87]) { // W - kamera ruch do przodu
    let Translation = new DOMMatrix();
    Translation.translateSelf(0, 0, MovementStep); // X Y Z
    CameraView.preMultiplySelf(Translation);
    MVCamera = CameraProjection.multiply(CameraView);
    ProjectionLocation = gl.getUniformLocation(sceneProgram, 'MVCamera');
    gl.uniformMatrix4fv(ProjectionLocation, false, MVCamera.toFloat32Array());
  }
  if(KeyStates[83]) { // S - kamera ruch w tył
    let Translation = new DOMMatrix();
    Translation.translateSelf(0, 0, -MovementStep); // X Y Z
    CameraView.preMultiplySelf(Translation);
    MVCamera = CameraProjection.multiply(CameraView);
    ProjectionLocation = gl.getUniformLocation(sceneProgram, 'MVCamera');
    gl.uniformMatrix4fv(ProjectionLocation, false, MVCamera.toFloat32Array());
  }
  if(KeyStates[65]) { // A - kamera ruch w lewo
    let Translation = new DOMMatrix();
    Translation.translateSelf(MovementStep, 0, 0); // X Y Z
    CameraView.preMultiplySelf(Translation);
    MVCamera = CameraProjection.multiply(CameraView);
    ProjectionLocation = gl.getUniformLocation(sceneProgram, 'MVCamera');
    gl.uniformMatrix4fv(ProjectionLocation, false, MVCamera.toFloat32Array());
  }
  if(KeyStates[68]) { // D - kamera ruch w prawo
    let Translation = new DOMMatrix();
    Translation.translateSelf(-MovementStep, 0, 0); // X Y Z
    CameraView.preMultiplySelf(Translation);
    MVCamera = CameraProjection.multiply(CameraView);
    ProjectionLocation = gl.getUniformLocation(sceneProgram, 'MVCamera');
    gl.uniformMatrix4fv(ProjectionLocation, false, MVCamera.toFloat32Array());
  }
  if(KeyStates[82]) { // R - kamera ruch w góre
    let Translation = new DOMMatrix();
    Translation.translateSelf(0, -MovementStep, 0); // X Y Z
    CameraView.preMultiplySelf(Translation);
    MVCamera = CameraProjection.multiply(CameraView);
    ProjectionLocation = gl.getUniformLocation(sceneProgram, 'MVCamera');
    gl.uniformMatrix4fv(ProjectionLocation, false, MVCamera.toFloat32Array());
  }
  if(KeyStates[70]) { // F - kamera ruch w dół
    let Translation = new DOMMatrix();
    Translation.translateSelf(0, MovementStep, 0); // X Y Z
    CameraView.preMultiplySelf(Translation);
    MVCamera = CameraProjection.multiply(CameraView);
    ProjectionLocation = gl.getUniformLocation(sceneProgram, 'MVCamera');
    gl.uniformMatrix4fv(ProjectionLocation, false, MVCamera.toFloat32Array());
  }
  if(KeyStates[69]) { // E - kamera obrot w prawo
    let Translation = new DOMMatrix();
    Translation.rotateSelf(0, MovementAngle, 0, 1); // X Y Z
    CameraView.preMultiplySelf(Translation);
    MVCamera = CameraProjection.multiply(CameraView);
    ProjectionLocation = gl.getUniformLocation(sceneProgram, 'MVCamera');
    gl.uniformMatrix4fv(ProjectionLocation, false, MVCamera.toFloat32Array());
  }
  if(KeyStates[81]) { // Q - kamera obrot w lewo
    let Translation = new DOMMatrix();
    Translation.rotateSelf(0, -MovementAngle, 0, 1); // X Y Z
    CameraView.preMultiplySelf(Translation);
    MVCamera = CameraProjection.multiply(CameraView);
    ProjectionLocation = gl.getUniformLocation(sceneProgram, 'MVCamera');
    gl.uniformMatrix4fv(ProjectionLocation, false, MVCamera.toFloat32Array());
  }
  if(KeyStates[90]) { // Z - kamera obrot w góre
    let Translation = new DOMMatrix();
    Translation.rotateSelf(-MovementAngle, 0, 0, 1); // X Y Z
    CameraView.preMultiplySelf(Translation);
    MVCamera = CameraProjection.multiply(CameraView);
    ProjectionLocation = gl.getUniformLocation(sceneProgram, 'MVCamera');
    gl.uniformMatrix4fv(ProjectionLocation, false, MVCamera.toFloat32Array());
  }
  if(KeyStates[88]) { // X - kamera obrót w dół
    let Translation = new DOMMatrix();
    Translation.rotateSelf(MovementAngle, 0, 0, 1); // X Y Z
    CameraView.preMultiplySelf(Translation);
    MVCamera = CameraProjection.multiply(CameraView);
    ProjectionLocation = gl.getUniformLocation(sceneProgram, 'MVCamera');
    gl.uniformMatrix4fv(ProjectionLocation, false, MVCamera.toFloat32Array());
  }
  if(KeyStates[67]) { // C - przewrót w lewo
    let Translation = new DOMMatrix();
    Translation.rotateSelf(0, 0, MovementAngle, 1); // X Y Z
    CameraView.preMultiplySelf(Translation);
    MVCamera = CameraProjection.multiply(CameraView);
    ProjectionLocation = gl.getUniformLocation(sceneProgram, 'MVCamera');
    gl.uniformMatrix4fv(ProjectionLocation, false, MVCamera.toFloat32Array());
  }
  if(KeyStates[86]) { // V - przewrót w prawo
    let Translation = new DOMMatrix();
    Translation.rotateSelf(0, 0, -MovementAngle, 1); // X Y Z
    CameraView.preMultiplySelf(Translation);
    MVCamera = CameraProjection.multiply(CameraView);
    ProjectionLocation = gl.getUniformLocation(sceneProgram, 'MVCamera');
    gl.uniformMatrix4fv(ProjectionLocation, false, MVCamera.toFloat32Array());
  }
  if(KeyStates[32]) { // SPACJA - reset kamery
    CameraStartingPosition = new DOMPoint(CameraX, CameraY, CameraZ);
    CameraView = LookAt(CameraStartingPosition, new DOMPoint(0, CameraY, 0));
    CameraProjection = CreatePerspective(GlobalVOF, GlobalRatio, 0.001, 100);
    MVCamera = CameraProjection.multiply(CameraView);
    ProjectionLocation = gl.getUniformLocation(sceneProgram, 'MVCamera');
    gl.uniformMatrix4fv(ProjectionLocation, false, MVCamera.toFloat32Array());
  }
}
function MoveLight() {
  if(KeyStates[73]) { // I - obrót światła wokół osi X w przód
    // Rotate light location around 0,0,0
    let TranslatedPoint = new DOMPoint(LightX, LightY, LightZ);
    let Translation = new DOMMatrix();
    Translation = Translation.rotate(MovementAngle, 0, 0);
    TranslatedPoint = Translation.transformPoint(TranslatedPoint);
    LightX = TranslatedPoint.x;
    LightY = TranslatedPoint.y;
    LightZ = TranslatedPoint.z;
    
    // Setup Light
    ReverseLightVector = VectorNormalize(new DOMPoint(LightX, LightY, LightZ));
    LightLocation = gl.getUniformLocation(sceneProgram, 'LightDirection');
    gl.uniform3fv(LightLocation, new Float32Array([ReverseLightVector.x, ReverseLightVector.y, ReverseLightVector.z]));
    LightProjection = CreateOrthogonalPerspective(-10, 10, 10, -10, -10, 10); // good enough projection size, mess up the program shader to see light perspective
    LightView = LookAt(ReverseLightVector, new DOMPoint(0, 0, 0));
    MVLight = LightProjection.multiply(LightView);
    MVLightDepth = gl.getUniformLocation(depthProgram, 'MVLight');
    gl.useProgram(depthProgram);
    gl.uniformMatrix4fv(MVLightDepth, false, MVLight.toFloat32Array());

    // [-1,1] -> [0,1] (UV)
    TextureCorrectionMap = new DOMMatrix([
      0.5, 0.0, 0.0, 0.0,
      0.0, 0.5, 0.0, 0.0,
      0.0, 0.0, 0.5, 0.0,
      0.5, 0.5, 0.5, 1.0
    ]);
    // Light perspective coordinates -> texture coordinates
    MVTexture = TextureCorrectionMap.multiplySelf(MVLight);
    // Update texture mapping in shader program
    MVLightCasted = gl.getUniformLocation(sceneProgram, 'MVLight');
    gl.useProgram(sceneProgram);
    gl.uniformMatrix4fv(MVLightCasted, false, MVTexture.toFloat32Array());

    // Refresh shadowmap frame buffer
    depthFramebuffer = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, depthFramebuffer);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, depthTexture, 0);
    shadowMapLocation = gl.getUniformLocation(sceneProgram, 'shadowMapTexture');
  }
  if(KeyStates[75]) { // K - obrót światła wokół osi X w tył
    // Rotate light location around 0,0,0
    let TranslatedPoint = new DOMPoint(LightX, LightY, LightZ);
    let Translation = new DOMMatrix();
    Translation = Translation.rotate(-MovementAngle, 0, 0);
    TranslatedPoint = Translation.transformPoint(TranslatedPoint);
    LightX = TranslatedPoint.x;
    LightY = TranslatedPoint.y;
    LightZ = TranslatedPoint.z;
    
    // Setup Light
    ReverseLightVector = VectorNormalize(new DOMPoint(LightX, LightY, LightZ));
    LightLocation = gl.getUniformLocation(sceneProgram, 'LightDirection');
    gl.uniform3fv(LightLocation, new Float32Array([ReverseLightVector.x, ReverseLightVector.y, ReverseLightVector.z]));
    LightProjection = CreateOrthogonalPerspective(-10, 10, 10, -10, -10, 10); // good enough projection size, mess up the program shader to see light perspective
    LightView = LookAt(ReverseLightVector, new DOMPoint(0, 0, 0));
    MVLight = LightProjection.multiply(LightView);
    MVLightDepth = gl.getUniformLocation(depthProgram, 'MVLight');
    gl.useProgram(depthProgram);
    gl.uniformMatrix4fv(MVLightDepth, false, MVLight.toFloat32Array());

    // [-1,1] -> [0,1] (UV)
    TextureCorrectionMap = new DOMMatrix([
      0.5, 0.0, 0.0, 0.0,
      0.0, 0.5, 0.0, 0.0,
      0.0, 0.0, 0.5, 0.0,
      0.5, 0.5, 0.5, 1.0
    ]);
    // Light perspective coordinates -> texture coordinates
    MVTexture = TextureCorrectionMap.multiplySelf(MVLight);
    // Update texture mapping in shader program
    MVLightCasted = gl.getUniformLocation(sceneProgram, 'MVLight');
    gl.useProgram(sceneProgram);
    gl.uniformMatrix4fv(MVLightCasted, false, MVTexture.toFloat32Array());

    // Refresh shadowmap frame buffer
    depthFramebuffer = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, depthFramebuffer);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, depthTexture, 0);
    shadowMapLocation = gl.getUniformLocation(sceneProgram, 'shadowMapTexture');
  }
  if(KeyStates[74]) { // J - obrót światła wokół osi Y w lewo
    // Rotate light location around 0,0,0
    let TranslatedPoint = new DOMPoint(LightX, LightY, LightZ);
    let Translation = new DOMMatrix();
    Translation = Translation.rotate(0, -MovementAngle, 0);
    TranslatedPoint = Translation.transformPoint(TranslatedPoint);
    LightX = TranslatedPoint.x;
    LightY = TranslatedPoint.y;
    LightZ = TranslatedPoint.z;
    
    // Setup Light
    ReverseLightVector = VectorNormalize(new DOMPoint(LightX, LightY, LightZ));
    LightLocation = gl.getUniformLocation(sceneProgram, 'LightDirection');
    gl.uniform3fv(LightLocation, new Float32Array([ReverseLightVector.x, ReverseLightVector.y, ReverseLightVector.z]));
    LightProjection = CreateOrthogonalPerspective(-10, 10, 10, -10, -10, 10); // good enough projection size, mess up the program shader to see light perspective
    LightView = LookAt(ReverseLightVector, new DOMPoint(0, 0, 0));
    MVLight = LightProjection.multiply(LightView);
    MVLightDepth = gl.getUniformLocation(depthProgram, 'MVLight');
    gl.useProgram(depthProgram);
    gl.uniformMatrix4fv(MVLightDepth, false, MVLight.toFloat32Array());

    // [-1,1] -> [0,1] (UV)
    TextureCorrectionMap = new DOMMatrix([
      0.5, 0.0, 0.0, 0.0,
      0.0, 0.5, 0.0, 0.0,
      0.0, 0.0, 0.5, 0.0,
      0.5, 0.5, 0.5, 1.0
    ]);
    // Light perspective coordinates -> texture coordinates
    MVTexture = TextureCorrectionMap.multiplySelf(MVLight);
    // Update texture mapping in shader program
    MVLightCasted = gl.getUniformLocation(sceneProgram, 'MVLight');
    gl.useProgram(sceneProgram);
    gl.uniformMatrix4fv(MVLightCasted, false, MVTexture.toFloat32Array());

    // Refresh shadowmap frame buffer
    depthFramebuffer = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, depthFramebuffer);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, depthTexture, 0);
    shadowMapLocation = gl.getUniformLocation(sceneProgram, 'shadowMapTexture');
  }
  if(KeyStates[76]) { // L - obrót światła wokół osi Y w prawo
    // Rotate light location around 0,0,0
    let TranslatedPoint = new DOMPoint(LightX, LightY, LightZ);
    let Translation = new DOMMatrix();
    Translation = Translation.rotate(0, MovementAngle, 0);
    TranslatedPoint = Translation.transformPoint(TranslatedPoint);
    LightX = TranslatedPoint.x;
    LightY = TranslatedPoint.y;
    LightZ = TranslatedPoint.z;
    
    // Setup Light
    ReverseLightVector = VectorNormalize(new DOMPoint(LightX, LightY, LightZ));
    LightLocation = gl.getUniformLocation(sceneProgram, 'LightDirection');
    gl.uniform3fv(LightLocation, new Float32Array([ReverseLightVector.x, ReverseLightVector.y, ReverseLightVector.z]));
    LightProjection = CreateOrthogonalPerspective(-10, 10, 10, -10, -10, 10); // good enough projection size, mess up the program shader to see light perspective
    LightView = LookAt(ReverseLightVector, new DOMPoint(0, 0, 0));
    MVLight = LightProjection.multiply(LightView);
    MVLightDepth = gl.getUniformLocation(depthProgram, 'MVLight');
    gl.useProgram(depthProgram);
    gl.uniformMatrix4fv(MVLightDepth, false, MVLight.toFloat32Array());

    // [-1,1] -> [0,1] (UV)
    TextureCorrectionMap = new DOMMatrix([
      0.5, 0.0, 0.0, 0.0,
      0.0, 0.5, 0.0, 0.0,
      0.0, 0.0, 0.5, 0.0,
      0.5, 0.5, 0.5, 1.0
    ]);
    // Light perspective coordinates -> texture coordinates
    MVTexture = TextureCorrectionMap.multiplySelf(MVLight);
    // Update texture mapping in shader program
    MVLightCasted = gl.getUniformLocation(sceneProgram, 'MVLight');
    gl.useProgram(sceneProgram);
    gl.uniformMatrix4fv(MVLightCasted, false, MVTexture.toFloat32Array());

    // Refresh shadowmap frame buffer
    depthFramebuffer = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, depthFramebuffer);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, depthTexture, 0);
    shadowMapLocation = gl.getUniformLocation(sceneProgram, 'shadowMapTexture');
  }
  if(KeyStates[85]) { // U - obrót światła wokół osi Z w prawo
    // Rotate light location around 0,0,0
    let TranslatedPoint = new DOMPoint(LightX, LightY, LightZ);
    let Translation = new DOMMatrix();
    Translation = Translation.rotate(0, 0, -MovementAngle);
    TranslatedPoint = Translation.transformPoint(TranslatedPoint);
    LightX = TranslatedPoint.x;
    LightY = TranslatedPoint.y;
    LightZ = TranslatedPoint.z;
    
    // Setup Light
    ReverseLightVector = VectorNormalize(new DOMPoint(LightX, LightY, LightZ));
    LightLocation = gl.getUniformLocation(sceneProgram, 'LightDirection');
    gl.uniform3fv(LightLocation, new Float32Array([ReverseLightVector.x, ReverseLightVector.y, ReverseLightVector.z]));
    LightProjection = CreateOrthogonalPerspective(-10, 10, 10, -10, -10, 10); // good enough projection size, mess up the program shader to see light perspective
    LightView = LookAt(ReverseLightVector, new DOMPoint(0, 0, 0));
    MVLight = LightProjection.multiply(LightView);
    MVLightDepth = gl.getUniformLocation(depthProgram, 'MVLight');
    gl.useProgram(depthProgram);
    gl.uniformMatrix4fv(MVLightDepth, false, MVLight.toFloat32Array());

    // [-1,1] -> [0,1] (UV)
    TextureCorrectionMap = new DOMMatrix([
      0.5, 0.0, 0.0, 0.0,
      0.0, 0.5, 0.0, 0.0,
      0.0, 0.0, 0.5, 0.0,
      0.5, 0.5, 0.5, 1.0
    ]);
    // Light perspective coordinates -> texture coordinates
    MVTexture = TextureCorrectionMap.multiplySelf(MVLight);
    // Update texture mapping in shader program
    MVLightCasted = gl.getUniformLocation(sceneProgram, 'MVLight');
    gl.useProgram(sceneProgram);
    gl.uniformMatrix4fv(MVLightCasted, false, MVTexture.toFloat32Array());

    // Refresh shadowmap frame buffer
    depthFramebuffer = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, depthFramebuffer);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, depthTexture, 0);
    shadowMapLocation = gl.getUniformLocation(sceneProgram, 'shadowMapTexture');
  }
  if(KeyStates[79]) { // O - obrót światła wokół osi Z w lewo
    // Rotate light location around 0,0,0
    let TranslatedPoint = new DOMPoint(LightX, LightY, LightZ);
    let Translation = new DOMMatrix();
    Translation = Translation.rotate(0, 0, MovementAngle);
    TranslatedPoint = Translation.transformPoint(TranslatedPoint);
    LightX = TranslatedPoint.x;
    LightY = TranslatedPoint.y;
    LightZ = TranslatedPoint.z;
    
    // Setup Light
    ReverseLightVector = VectorNormalize(new DOMPoint(LightX, LightY, LightZ));
    LightLocation = gl.getUniformLocation(sceneProgram, 'LightDirection');
    gl.uniform3fv(LightLocation, new Float32Array([ReverseLightVector.x, ReverseLightVector.y, ReverseLightVector.z]));
    LightProjection = CreateOrthogonalPerspective(-10, 10, 10, -10, -10, 10); // good enough projection size, mess up the program shader to see light perspective
    LightView = LookAt(ReverseLightVector, new DOMPoint(0, 0, 0));
    MVLight = LightProjection.multiply(LightView);
    MVLightDepth = gl.getUniformLocation(depthProgram, 'MVLight');
    gl.useProgram(depthProgram);
    gl.uniformMatrix4fv(MVLightDepth, false, MVLight.toFloat32Array());

    // [-1,1] -> [0,1] (UV)
    TextureCorrectionMap = new DOMMatrix([
      0.5, 0.0, 0.0, 0.0,
      0.0, 0.5, 0.0, 0.0,
      0.0, 0.0, 0.5, 0.0,
      0.5, 0.5, 0.5, 1.0
    ]);
    // Light perspective coordinates -> texture coordinates
    MVTexture = TextureCorrectionMap.multiplySelf(MVLight);
    // Update texture mapping in shader program
    MVLightCasted = gl.getUniformLocation(sceneProgram, 'MVLight');
    gl.useProgram(sceneProgram);
    gl.uniformMatrix4fv(MVLightCasted, false, MVTexture.toFloat32Array());

    // Refresh shadowmap frame buffer
    depthFramebuffer = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, depthFramebuffer);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, depthTexture, 0);
    shadowMapLocation = gl.getUniformLocation(sceneProgram, 'shadowMapTexture');
  }
}